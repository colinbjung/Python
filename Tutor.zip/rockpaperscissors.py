import random

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

# User enters their choice 
# Display User's choice with ASCII Art
# Display computer choice
# Display Computer's choice with ASCII Art
# Say who won or lost or draw

# I want you to try to utilize list 
# Try to make it as little if statements as possible by using logical operator AND open

def rockpaperscissors():
  compchoice = random.randint(0, 3)
  playerchoice = int(input("Choose 1 for rock, 2 for paper, and 3 for scissors."))
  if compchoice == 1:
    print("The computer played rock.")
  if compchoice == 2:
    print("The computer played paper.")
  if compchoice == 3:
    print("The computer played scissors.")
  if playerchoice == 1:
    print("You played rock.")
  if playerchoice == 2:
    print("You played paper.")
  if playerchoice == 3:
    print("You played scissors.")

  if playerchoice == compchoice:
    print("Tie.")
  if playerchoice - compchoice = 1:
    print("You win!")
  if compchoice - playerchoice = 1:
    print("You lose.")
  if compchoice - playerchoice = 2:
    print("You win!")
  if playerchoice - compchoice = 2:
    print("You lose.")

rockpaperscissors()

