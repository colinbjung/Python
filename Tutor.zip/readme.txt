Python text-based rock paper scissors game

------------------------------------------------------------------------
EXAMPLE GAMEPLAY:

Choose 1 for rock, 2 for paper, and 3 for scissors.3
Player chose: scissors

    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)

Computer chose: scissors

    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)

Draw
-------------------------------------------------------------------------